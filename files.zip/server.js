const express = require("express");
const fetch = require("node-fetch");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

const ELEVENLABS_KEY = "sk_f05fede49def6bd86957836c68838e0e69fc86c2be2cf5cd";
const PINTEREST_BOARD = "https://au.pinterest.com/yorosurfnstuff/bokai/";

// ─── HEALTH CHECK ────────────────────────────────────────────────────────────
app.get("/", (req, res) => res.json({ status: "Sasha Cove Backend Running" }));

// ─── PINTEREST SCRAPER ───────────────────────────────────────────────────────
// Fetches Pinterest board images to use as scene references
app.get("/api/pinterest/scenes", async (req, res) => {
  try {
    const category = req.query.category || "beach";

    // Pinterest API v3 — fetch board pins
    const boardUrl = `https://www.pinterest.com/resource/BoardFeedResource/get/?source_url=%2Fyorosurfnstuff%2Fbokai%2F&data=%7B%22options%22%3A%7B%22board_id%22%3A%22%22%2C%22board_url%22%3A%22%2Fyorosurfnstuff%2Fbokai%2F%22%2C%22currentFilter%22%3A-1%2C%22field_set_key%22%3A%22react_grid_pin%22%2C%22filter_section_pins%22%3Atrue%2C%22layout%22%3A%22default%22%2C%22page_size%22%3A25%2C%22redux_normalize_feed%22%3Atrue%7D%2C%22context%22%3A%7B%7D%7D`;

    const pinterestRes = await fetch(boardUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "X-Requested-With": "XMLHttpRequest",
        "Accept": "application/json",
      },
    });

    let imageUrls = [];

    if (pinterestRes.ok) {
      const data = await pinterestRes.json();
      const pins = data?.resource_response?.data || [];
      imageUrls = pins
        .filter(pin => pin?.images?.orig?.url)
        .map(pin => pin.images.orig.url)
        .slice(0, 20);
    }

    // Fallback — curated coastal Australian girl scenes if Pinterest is blocked
    if (imageUrls.length === 0) {
      const fallbacks = {
        beach: [
          "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800",
          "https://images.unsplash.com/photo-1519046904884-53103b34b206?w=800",
          "https://images.unsplash.com/photo-1473186578172-c141e6798cf4?w=800",
          "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800",
          "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800",
        ],
        cafe: [
          "https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=800",
          "https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=800",
          "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=800",
        ],
        city: [
          "https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?w=800",
          "https://images.unsplash.com/photo-1524293581917-878a6d017c71?w=800",
          "https://images.unsplash.com/photo-1534430480872-3498386e7856?w=800",
        ],
        gym: [
          "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800",
          "https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=800",
        ],
        home: [
          "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=800",
          "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800",
        ],
        nature: [
          "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800",
          "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800",
        ],
        car: [
          "https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?w=800",
          "https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=800",
        ],
      };
      imageUrls = fallbacks[category] || fallbacks.beach;
    }

    res.json({ success: true, images: imageUrls, source: imageUrls.length > 5 ? "pinterest" : "fallback" });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─── ELEVENLABS VOCAL GENERATION ────────────────────────────────────────────
// Generates a short vocal clip of Sasha "singing" a hook from the trending song
app.post("/api/vocal/generate", async (req, res) => {
  try {
    const { songName, emotion } = req.body;

    // Pick a short lyric hook based on emotion to "sing"
    const hooks = {
      lust: ["la la la, summer is here", "ooh, golden hour with me", "hey, come find me at the beach"],
      jealousy: ["mm, bet you wish you were here", "oh, living my best life", "yeah, this is my world"],
      fantasy: ["hmm, dreaming out loud", "la la, somewhere beautiful", "oh, soft golden light"],
      curiosity: ["hey, you know where to find me", "mm, not everything makes the feed", "ooh, come a little closer"],
      validation: ["yeah, I showed up today", "mm, glowing and growing", "oh, she chose herself again"],
    };

    const hook = hooks[emotion] ? hooks[emotion][Math.floor(Math.random() * hooks[emotion].length)] : hooks.lust[0];

    const voiceId = "21m00Tcm4TlvDq8ikWAM"; // Rachel — natural female voice

    const elRes = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
      method: "POST",
      headers: {
        "xi-api-key": ELEVENLABS_KEY,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        text: hook,
        model_id: "eleven_monolingual_v1",
        voice_settings: { stability: 0.4, similarity_boost: 0.8, style: 0.3, use_speaker_boost: true },
      }),
    });

    if (!elRes.ok) {
      const err = await elRes.text();
      return res.status(500).json({ error: "ElevenLabs error: " + err });
    }

    const audioBuffer = await elRes.buffer();
    res.set("Content-Type", "audio/mpeg");
    res.set("Content-Disposition", `attachment; filename="sasha_vocal_${emotion}.mp3"`);
    res.set("Access-Control-Allow-Origin", "*");
    res.send(audioBuffer);

  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─── TRENDING SONGS (weekly updated) ────────────────────────────────────────
app.get("/api/trending/songs", async (req, res) => {
  // These are updated manually weekly — just hit this endpoint to get current songs
  const trending = {
    updated: "2026-04-24",
    songs: {
      lust: ["Titanium x Please Me - TRUE CHAD & Unjaps", "ALL THE LOVE - Kanye West", "Taste - Sabrina Carpenter", "Espresso - Sabrina Carpenter", "Good Luck Babe - Chappell Roan"],
      jealousy: ["Titanium x Please Me - TRUE CHAD & Unjaps", "Behind These Hazel Eyes - Kelly Clarkson", "Break My Stride - Matthew Wilder", "ALL THE LOVE - Kanye West", "Younger You - Miley Cyrus"],
      fantasy: ["april - ILOVEFLOWERS", "Only Time - Enya", "Hopelessly Devoted To You - Olivia Newton-John", "Birds of a Feather - Billie Eilish", "Stargazing - Myles Smith"],
      curiosity: ["Titanium x Please Me - TRUE CHAD & Unjaps", "That Should Be Me - Justin Bieber", "Easy - Commodores", "april - ILOVEFLOWERS", "Die With A Smile - Lady Gaga & Bruno Mars"],
      validation: ["Break My Stride - Matthew Wilder", "Younger You - Miley Cyrus", "Beautiful Things - Benson Boone", "Easy - Commodores", "Please Please Please - Sabrina Carpenter"],
    },
  };
  res.json(trending);
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Sasha backend running on port ${PORT}`));
